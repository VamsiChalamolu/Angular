using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Infosys.QuickKart.Common.Models
{
    public class Role
    {
        public byte RoleId { get; set; }
        public string RoleName { get; set; }

    }
}
